# @kit.GameServiceKit.d.ts

> API 26.0.0 Release declaration snapshot from DevEco Studio SDK 26.0.0.105.

```ts
/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
 */
/**
 * @file Defines the capabilities of GameServiceKit.
 * @kit GameServiceKit
 * @since 4.1.0(11)
 */
import gamePlayer from '@hms.core.gameservice.gameplayer';
import gamePerformance from '@hms.core.gameservice.gameperformance';
import gameNearbyTransfer from '@hms.core.gameservice.gamenearbytransfer';
export { gamePlayer, gamePerformance, gameNearbyTransfer };

```
