# @kit.EnterpriseDataGuardKit.d.ts

> API 26.0.0 Release declaration snapshot from DevEco Studio SDK 26.0.0.105.

```ts
/*
 * Copyright (c) 2024 Huawei Device Co., Ltd. All rights reserved.
 */
/**
 * @file This module providers the capability to mark and control documents.
 * @kit EnterpriseDataGuardKit
 * @since 4.1.0(11)
 */
import fileGuard from '@hms.pcService.fileGuard';
export { fileGuard, recoveryKey };
import recoveryKey from '@hms.pcService.recoveryKeyService';

```
