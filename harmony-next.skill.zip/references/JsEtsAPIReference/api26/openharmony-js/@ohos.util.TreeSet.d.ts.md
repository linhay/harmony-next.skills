# @ohos.util.TreeSet.d.ts

> API 26.0.0 Release declaration snapshot from DevEco Studio SDK 26.0.0.105.

```ts
/*
 * Copyright (c) 2021-2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file
 * @kit ArkTS
 */
/**
 * TreeSet is implemented based on TreeMap. In TreeSet, only value objects are processed.
 * TreeSet can be used to store values, each of which must be unique.
 *
 * @syscap SystemCapability.Utils.Lang
 * @crossplatform [since 10]
 * @atomicservice [since 12]
 * @since 8
 */
declare class TreeSet<T> {
    /**
     * A constructor used to create a TreeSet object.
     *
     * @param { function } [comparator] - comparator
     *     comparator (Optional) User-defined comparison functions.
     *     firstValue (required) previous element.
     *     secondValue (required) next element.
     * @throws { BusinessError } 10200012 - The TreeSet's constructor cannot be directly invoked.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    constructor(comparator?: (firstValue: T, secondValue: T) => boolean);
    /**
     * Gets the element number of the TreeSet.
     *
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    length: number;
    /**
     * Returns whether the Set object contains elements
     *
     * @returns { boolean } the boolean type
     * @throws { BusinessError } 10200011 - The isEmpty method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    isEmpty(): boolean;
    /**
     * Returns whether the Set object contains the elements
     *
     * @param { T } value - the value to check for presence in the set
     * @returns { boolean } the boolean type
     * @throws { BusinessError } 10200011 - The has method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    has(value: T): boolean;
    /**
     * If the set does not contain the element, the specified element is added
     *
     * @param { T } value - the element to add to the set
     * @returns { boolean } whether the element was already present
     * @throws { BusinessError } 10200011 - The add method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    add(value: T): boolean;
    /**
     * Remove a specified element from a Set object
     *
     * @param { T } value - the element to remove from the set
     * @returns { boolean } the boolean type(Is there contain this element)
     * @throws { BusinessError } 10200011 - The remove method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    remove(value: T): boolean;
    /**
     * Clears all element groups in a set
     *
     * @throws { BusinessError } 10200011 - The clear method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    clear(): void;
    /**
     * Gets the first elements in a set
     *
     * @returns { T } value or undefined
     * @throws { BusinessError } 10200011 - The getFirstValue method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    getFirstValue(): T;
    /**
     * Gets the last elements in a set
     *
     * @returns { T } value or undefined
     * @throws { BusinessError } 10200011 - The getLastValue method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    getLastValue(): T;
    /**
     * Returns the greatest element smaller than or equal to the specified key
     * if the key does not exist, undefined is returned
     *
     * @param { T } key - the key to compare against
     * @returns { T } key or undefined
     * @throws { BusinessError } 10200011 - The getLowerValue method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    getLowerValue(key: T): T;
    /**
     * Returns the least element greater than or equal to the specified key
     * if the key does not exist, undefined is returned
     *
     * @param { T } key - the key to compare against
     * @returns { T } key or undefined
     * @throws { BusinessError } 10200011 - The getHigherValue method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    getHigherValue(key: T): T;
    /**
     * Return and delete the first element, returns undefined if tree set is empty
     *
     * @returns { T } first value or undefined
     * @throws { BusinessError } 10200011 - The popFirst method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    popFirst(): T;
    /**
     * Return and delete the last element, returns undefined if tree set is empty
     *
     * @returns { T } last value or undefined
     * @throws { BusinessError } 10200011 - The popLast method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    popLast(): T;
    /**
     * Executes a provided function once for each value in the Set object.
     *
     * @param { function } callbackFn - callbackFn
     *     callbackFn (required) A function that accepts up to three arguments.
     *     The function to be called for each element.
     * @param { Object } [thisArg] - thisArg
     *     thisArg (Optional) The value to be used as this value for when callbackFn is called.
     *     If thisArg is omitted, undefined is used as the this value.
     * @throws { BusinessError } 10200011 - The forEach method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    forEach(callbackFn: (value?: T, key?: T, set?: TreeSet<T>) => void, thisArg?: Object): void;
    /**
     * Returns a new Iterator object that contains the values contained in this set
     *
     * @returns { IterableIterator<T> }
     * @throws { BusinessError } 10200011 - The values method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    values(): IterableIterator<T>;
    /**
     * Returns a new Iterator object that contains the [key, value] pairs for each element in the Set object in insertion
     * order
     *
     * @returns { IterableIterator<[T, T]> }
     * @throws { BusinessError } 10200011 - The entries method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    entries(): IterableIterator<[
        T,
        T
    ]>;
    /**
     * returns an ES6 iterator.Each item of the iterator is a Javascript Object
     *
     * @returns { IterableIterator<T> }
     * @throws { BusinessError } 10200011 - The Symbol.iterator method cannot be bound.
     * @syscap SystemCapability.Utils.Lang
     * @crossplatform [since 10]
     * @atomicservice [since 12]
     * @since 8
     */
    [Symbol.iterator](): IterableIterator<T>;
}
export default TreeSet;

```
